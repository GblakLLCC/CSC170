import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()

    {
        
        movePlayer();
        
        
    }
    public void movePlayer() {
    TempleRuins world = (TempleRuins) getWorld();
    String key = Greenfoot.getKey();
    if (key == null) return;

    int x = getX();
    int y = getY();
    Actor leftWall = getOneObjectAtOffset(-1,0,Wall.class);
    Actor rightWall = getOneObjectAtOffset(1,0,Wall.class);
    
    Actor upWall = getOneObjectAtOffset(0,-1,Wall.class);
    Actor downWall = getOneObjectAtOffset(0,1,Wall.class);
    

    if (key.equals("left") || key.equals("a")){
        if (leftWall == null){
            setLocation(x - 1, y);
        }
        
    }
    else if (key.equals("right") || key.equals("d")){
        if (rightWall == null){
            setLocation(x + 1, y);
        }
    }
    else if (key.equals("up") || key.equals("w")){
        if (upWall == null){
            setLocation(x, y-1);
        }
    }
    else if (key.equals("down") || key.equals("s")){
        if (downWall == null){
            setLocation(x, y+1);
        }
    }
    if (getOneObjectAtOffset(0,0,Gem.class) != null){
        removeTouching(Gem.class);
        world.showScore();
    }
    
    
}
}
