import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TempleRuins extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public TempleRuins()
    {    
        // Create a new world with 16 x 11 cells with a cell size of 60 pixels.
        super(16, 11, 60, true);        
        prepare();
        showText("Score: 0 / 5", 1, 0);
        
        
    }
    public void showScore()
    {
        Score.counter++;
        showText("Score: " + Score.counter + " / 5", 1, 0);
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Wall wall = new Wall();
        addObject(wall,0,8);
        Wall wall2 = new Wall();
        addObject(wall2,1,8);
        Wall wall3 = new Wall();
        addObject(wall3,2,8);
        Wall wall4 = new Wall();
        addObject(wall4,3,7);
        Wall wall5 = new Wall();
        addObject(wall5,3,6);
        Wall wall6 = new Wall();
        addObject(wall6,3,5);
        Wall wall7 = new Wall();
        addObject(wall7,0,2);
        Wall wall8 = new Wall();
        addObject(wall8,1,2);
        Wall wall9 = new Wall();
        addObject(wall9,2,2);
        Wall wall10 = new Wall();
        addObject(wall10,3,2);
        Wall wall11 = new Wall();
        addObject(wall11,4,2);
        Wall wall12 = new Wall();
        addObject(wall12,5,2);
        Wall wall13 = new Wall();
        addObject(wall13,6,3);
        Wall wall14 = new Wall();
        addObject(wall14,6,4);
        Wall wall15 = new Wall();
        addObject(wall15,6,5);
        Wall wall16 = new Wall();
        addObject(wall16,6,6);
        Wall wall17 = new Wall();
        addObject(wall17,6,7);
        Wall wall18 = new Wall();
        addObject(wall18,7,8);
        Enemy enemy = new Enemy();
        addObject(enemy,0,5);
        Gem gem = new Gem();
        addObject(gem,1,6);
        Wall wall19 = new Wall();
        addObject(wall19,8,8);
        Wall wall20 = new Wall();
        addObject(wall20,9,8);
        Wall wall21 = new Wall();
        addObject(wall21,10,8);
        Wall wall22 = new Wall();
        addObject(wall22,10,7);
        Wall wall23 = new Wall();
        addObject(wall23,10,6);
        Wall wall24 = new Wall();
        addObject(wall24,10,5);
        Enemy enemy2 = new Enemy();
        addObject(enemy2,7,5);
        Gem gem2 = new Gem();
        addObject(gem2,8,7);
        Wall wall25 = new Wall();
        addObject(wall25,15,6);
        Wall wall26 = new Wall();
        addObject(wall26,14,6);
        Wall wall27 = new Wall();
        addObject(wall27,13,6);
        Enemy enemy3 = new Enemy();
        addObject(enemy3,13,7);
        Gem gem3 = new Gem();
        addObject(gem3,15,9);
        Enemy enemy4 = new Enemy();
        addObject(enemy4,6,2);
        Wall wall28 = new Wall();
        addObject(wall28,11,0);
        Wall wall29 = new Wall();
        addObject(wall29,11,1);
        Wall wall30 = new Wall();
        addObject(wall30,11,2);
        Wall wall31 = new Wall();
        addObject(wall31,13,5);
        Wall wall32 = new Wall();
        addObject(wall32,14,5);
        Wall wall33 = new Wall();
        addObject(wall33,15,5);
        Enemy enemy5 = new Enemy();
        addObject(enemy5,12,2);
        Gem gem4 = new Gem();
        addObject(gem4,14,0);
        Gem gem5 = new Gem();
        addObject(gem5,3,0);
        Player player = new Player();
        addObject(player,4,9);
    }
}
