import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    static boolean moved = false;

    /**
     * Act - do whatever the Player wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act(){
        if (!Score.endGame){
            movePlayer();
        }
            
    }

    public void movePlayer() {
        TempleRuins world = (TempleRuins) getWorld();

        moved = false;
        String key = Greenfoot.getKey();

        if (key == null) return;
        int x = getX();
        int y = getY();
        Actor leftWall = getOneObjectAtOffset(-1,0,Wall.class);
        Actor rightWall = getOneObjectAtOffset(1,0,Wall.class);

        Actor upWall = getOneObjectAtOffset(0,-1,Wall.class);
        Actor downWall = getOneObjectAtOffset(0,1,Wall.class);
        
        
        if (key.equals("left") || key.equals("a")){
            if (getOneObjectAtOffset(-1,0,EnemyHorizontal.class) != null){
                world.showRounds();
                world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
                world.showText("Press Reset to try again", 8, 6);
                Score.endGame = true;
                Greenfoot.stop();
            }
            else if (leftWall == null){
                setLocation(x - 1, y);
            }
            
            moved = true;
            world.showRounds();
        }
        else if (key.equals("right") || key.equals("d")){
            if (getOneObjectAtOffset(1,0,EnemyHorizontal.class) != null){
                world.showRounds();
                world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
                world.showText("Press Reset to try again ", 8, 6);
                Score.endGame = true;
                Greenfoot.stop();
            }
            else if (rightWall == null){
                setLocation(x + 1, y);
            }
            moved = true;
            world.showRounds();
        }
        else if (key.equals("up") || key.equals("w")){
            if (getOneObjectAtOffset(0,-1,EnemyVertical.class) != null){
                world.showRounds();
                world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
                world.showText("Press Reset to try again ", 8, 6);
                Score.endGame = true;
                Greenfoot.stop();
            }
            else if (upWall == null){
                setLocation(x, y-1);
            }
            moved = true;
            world.showRounds();
        }
        else if (key.equals("down") || key.equals("s")){
            if (getOneObjectAtOffset(0,1,EnemyVertical.class) != null){
                world.showRounds();
                world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
                world.showText("Press Reset to try again ", 8, 6);
                Score.endGame = true;
                Greenfoot.stop();
            }
            else if (downWall == null){
                setLocation(x, y+1);
            }

            moved = true;
            world.showRounds();
        }
        if (getOneObjectAtOffset(0,0,EnemyVertical.class) != null){
            world.showRounds();
            world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
            world.showText("Press Reset to try again", 8, 6);
            Score.endGame = true;
            Greenfoot.stop();
        }

        if (getOneObjectAtOffset(0,0,Gem.class) != null){
            removeTouching(Gem.class);
            world.showScore();
            if (Score.gemCounter == 5){
                world.showText("You Win! You won in " + Score.rounds + " rounds", 8, 5);
                world.showText("Press Reset to play again ", 8, 6);
                Score.endGame = true;
                Greenfoot.stop();
            }
        }
    }
}
