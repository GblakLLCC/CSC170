import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Score here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Score extends Actor
{
    static boolean endGame = false;
    static int gemCounter = 0;
    static int rounds = 0;
    public void act()
    {
        // Add your action code here.
    }
}
