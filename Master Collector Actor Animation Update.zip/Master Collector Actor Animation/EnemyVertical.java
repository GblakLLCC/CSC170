import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyVertical here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyVertical extends Actor
{
    int direction = 1;
    
    public void act()
    {
        if (Player.moved && !Score.endGame){
            moveEnemy();
        }
    }
    public void moveEnemy(){
        TempleRuins world = (TempleRuins) getWorld();

        Actor wall = getOneObjectAtOffset(0,direction,Wall.class);
        
        int x = getX();
        int y = getY();
        if (wall != null || isAtEdge()){
            direction = -direction;
            
        
        }
        setLocation(x, y + direction);
        
        if (getOneObjectAtOffset(0,0,Player.class) != null){
            world.showRounds();
            world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
            world.showText("Press Reset to try again", 8, 6);
            Greenfoot.stop();
        }
    
    }
}
