import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyHorizontal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyHorizontal extends Actor
{
    int direction = 1;
    boolean turnAround = false;
    
    public void act()
    {
        if (Player.moved && !Score.endGame){
            moveEnemy();
        }
    }
    public void moveEnemy(){
        TempleRuins world = (TempleRuins) getWorld();

        Actor wall = getOneObjectAtOffset(direction,0,Wall.class);
        
        int x = getX();
        int y = getY();
        if (wall != null || isAtEdge()){
            direction = -direction;
            turnAround = true;
            
        
        }
        setLocation(x + direction, y);
        
        if (getOneObjectAtOffset(0,0,Player.class) != null){
            world.showRounds();
            world.showText("You Lose! You Died in " + Score.rounds + " rounds", 8, 5);
            world.showText("Press Reset to try again", 8, 6);
            Greenfoot.stop();
        }
    
    }
}
